function qe = rotate_q(q,p)

q0 = q(1);
qv = [q(2);q(3);q(4)];
p0 = p(1);
pv = [p(2);p(3);p(4)];

qe_0 = q0*p0-qv'*pv;
qe_v = q0*pv+p0*qv+cross(qv,pv);

qe = [qe_0;qe_v];