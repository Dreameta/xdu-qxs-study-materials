#include <stdio.h>
#define N 2000
#define M 10
struct data
		{
			char title[3][80];
		 	double total[N][8];
			int grid[N][2];
			double pos[N][2];
			double vel[N][2];
	
		};

struct Restress
		{
			double SUvel[N][2];
			double SVvel[N][2];
			double SUVvel[N];
			double ReUU[N];
			double ReVV[N];
			double ReUV[N];
			
		};
	
void readfile(char * filename, struct data * p)
{
/*----------------------ѭ����ȡ�ļ���------------------------------*/
		FILE * f = 0 ;
		int j = 0, k = 0;
		if ((f = fopen(filename, "r")) == NULL)
	 		{	
	 		printf("can't open flie\n");
	 			exit(0);
	 		}
	 	
	 			printf("%s\n",filename);
			
/*----------------------------------------------------------------*/			
/*----------------------��ȡ.dat�ļ���ͷ������Ҫ����ĸ-----------------------*/			
			   for(j = 0; j < 3; j++)
		 		   for(k = 0; k < 80; k++) 
 					  {
 						char ch;
					 	fread(&ch,sizeof(char),1,f);
					 	p->title[j][k] = ch;
						//printf("%c",p->title[j][k]);
						if(ch == '\n')
							{
								break;
							}
					   }
					   
/*----------------------------------------------------------------*/			
/*----------------------��ȡ������total��ά������---------------------------*/	
				
			    for(j = 0; j < N; j++) 
		   			for(k = 0; k < 8; k++)
			   			{
	   				 		double fNum = 0; 
	    		 	 		fscanf(f,"%lf",&fNum);
					   		p->total[j][k] = fNum;	    		 	
				    		//printf("%lf ",p->total[j][k]);
					    	//printf("%s","");
				 
				 		} 
				 		putchar('\n');
/*----------------------------------------------------------------*/			
/*----------------------��total�����е����ݰ���������������������----------*/
				for(j = 0; j < 2; j++)
			   		for(k = 0; k < N; k++)
			   		   	p->grid[k][j] = p->total[k][j];
				
				
				for(j = 2; j < 4; j++)
		 			for(k = 0; k < N; k++)
					   p->pos[k][j-2] = p->total[k][j];
					   		   		
					   		   		
			    for(j = 4; j < 6; j++)
		    		for(k = 0; k < N; k++)
					   p->vel[k][j-4] = p->total[k][j];				 
		 
				 
/*----------------------------------------------------------------*/				 
/*----------------------------------------------------------------*/				 
				 
                        fclose(f);	 
				 
				 return ;
}
	void operation(struct data * p, struct Restress * q)
							{
								 int i = 0, j = 0, k = 0;
									for(j = 0; j < 2; j++)
	 									 for(k = 0; k < N; k++)
								   	        {
								   	        	if(0 == j)
   										   			for(i = 0; i < 30; i++)
	   										   		   {
															 q->SUvel[k][j] = q->SUvel[k][j]+(p+i)->vel[k][j];
															 
					   		   			                     q->SVvel[k][j] = q->SVvel[k][j]+(p+i)->vel[k][j+1];
											            }
				   		   						else
				   		   							for(i = 0; i < 30; i++)
				   		   						    	{
															  q->SUvel[k][j] = q->SUvel[k][j]+((p+i)->vel[k][j-1]*(p+i)->vel[k][j-1]);
														      q->SVvel[k][j] = q->SVvel[k][j]+((p+i)->vel[k][j]*(p+i)->vel[k][j]);
										                 }
	   										   	 	
								   	         }
										
	 									 	for(k = 0; k < N; k++)
											  	  for(i = 0; i < 30; i++)
												    {
    													q->SUVvel[k] = q->SUVvel[k]+((p+i)->vel[k][0]*(p+i)->vel[k][1]);
    												}
	   										   		
 										 	for(k = 0; k < N; k++)
 										 			{
			 										 	q->ReUU[k] = ((q->SUvel[k][0])/30)*((q->SUvel[k][0])/30)-((q->SUvel[k][1])/30);
			 										 	q->ReVV[k] = ((q->SVvel[k][0])/30)*((q->SVvel[k][0])/30)-((q->SVvel[k][1])/30);
			 										 	q->ReUV[k] = ((q->SUvel[k][0])/30)*((q->SVvel[k][0])/30)-((q->SUVvel[k])/30);
			 										 }
	 										
											 return ; 
															
							}
int main(int argc, char *argv[])
{
	struct data a[30]= {0};
	struct Restress R = {0.0};
	char fname[50]=" ";
	int i = 0, j = 0, k = 0, sum = 0;
	
	
	for(i = 0; i < 3; i++)
		for(j = 0; j < M; j++)
		{
 			sprintf(fname, "F:\\chuli\\F30.360dpj0n.0000%d%d.dat", i,j);
	 		 sum = sum + 1;
			  //printf ("%d\n",sum);	
			 readfile(fname,&a[sum-1]); 
	 		
	 	}

 	        operation(a,&R);
   			
             printf("������\n");
		     for(k = 0; k < N; k++)
		        printf("%lf %lf %lf\n",R.ReUU[k],R.ReVV[k],R.ReUV[k]);
	   
	return 0;
}
