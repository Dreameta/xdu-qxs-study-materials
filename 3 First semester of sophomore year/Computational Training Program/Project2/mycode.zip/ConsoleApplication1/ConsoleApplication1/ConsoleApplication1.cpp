﻿// ConsoleApplication1.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

//时间：2021年11月27日
//目的：处理50个数据文件，每个文件10336条有效数据。
//		输出A,B,C

#include <iostream>
#include<malloc.h>
#include<stdlib.h>
#include<string.h>
#include <stdio.h>

//存储原始数据
struct value {
	char x[5], y[5], xval[20], yval[20], u[20], v[20], l[20];
	struct value* next;
}*head;

//储存所需结果文件
struct values {
	double x[10336], y[10336], u[10336], v[10336];
}vals[50];

//输出结果文件
struct Restress {
	double a;
	double b;
	double c;
}result[10336];

char fileloc[400];

//函数初始化
void Input(void);
void Operation(void); 
void Output(void);

//主函数
int main()
{
	
	printf("请输入读取文件的路径：(例如：D:\\Origdata）\n");
	gets_s(fileloc);

	//读取数据
	Input();
	//处理数据
	Operation();
	//输出数据
	Output();

	return 0;
}

//输入函数
void Input(void) {
	FILE* fp;
	char filename[400];
	int flag, i, m = 0, j;
	struct value* p1, * p2;

	//依次读入每个文件

	printf("\n开始读取文件名字信息\n\n");
	while (m < 50) {
		if (m < 10) {
			sprintf_s(filename, "%s\\Export-dat.6rw80dwa.00000%d.dat", fileloc, m);
		}
		else {
			sprintf_s(filename, "%s\\Export-dat.6rw80dwa.0000%d.dat", fileloc, m);
		}
		printf("已读取文件：	");
		printf("%s\n", filename);

		//打开文件
		fopen_s(&fp, filename, "r");

		//将文件信息存入数据库，将读出的信息存放在链表中
		if (fp == NULL) {
			printf("未能初始化第%d个文件的信息\n", m);
			return;
		}

		else {
			flag = 0;
			i = 1;
			j = 0;
			p1 = (struct value*)malloc(sizeof(struct value));
			head = p1;
			p2 = NULL;

			while (!feof(fp) && flag < 10337) {
				//前三行读取
				//interaction：跳过n行，则多输入n行如下代码
				if (flag == 0) {
					fscanf_s(fp, "%*[^\n]%*c");
					fscanf_s(fp, "%*[^\n]%*c");
					fscanf_s(fp, "%*[^\n]%*c");
					flag = 1;
				}

				//之后每行进行读取
				//interaction：对应文件有m个数据，则对应读取相应的数据
				fscanf_s(fp, "%s", p1->x, 5);
				fscanf_s(fp, "%s", p1->y, 5);
				fscanf_s(fp, "%s", p1->xval, 20);
				fscanf_s(fp, "%s", p1->yval, 20);
				fscanf_s(fp, "%s", p1->u, 20);
				fscanf_s(fp, "%s", p1->v, 20);
				fscanf_s(fp, "%s\n", p1->l, 20);

				p2 = p1;
				p1 = (struct value*)malloc(sizeof(struct value));
				p2->next = p1;

				vals[m].x[j] = atof(p2->x);	 //字符串转浮点
				vals[m].y[j] = atof(p2->y);
				vals[m].u[j] = atof(p2->u);
				vals[m].v[j] = atof(p2->v);

				j++;
				flag++;

			}

			p2->next = NULL;
			p2 = NULL;

			free(p1);
			fclose(fp);
		}
		m++;
	}
	return;
}

//操作函数
void Operation(void) {
	//interaction：可以依据具体计算结构进行调整计算
	double sumu[10336] = { 0 }, sumv[10336] = { 0 }, sumuv[10336] = { 0 };
	double sumuu[10336] = { 0 }, sumvv[10336] = { 0 }, averu[10336] = { 0 }, averv[10336] = { 0 };

	for (int i = 0; i < 10336; i++) {
		for (int m = 0; m < 50; m++) {
			sumu[i] = sumu[i] + vals[m].u[i];
			averu[i] = sumu[i] / 50;

			sumv[i] = sumv[i] + vals[m].v[i];
			averv[i] = sumv[i] / 50;

			sumuv[i] = sumuv[i] + vals[m].u[i] * vals[m].v[i];
			sumuu[i] = sumuu[i] + vals[m].u[i] * vals[m].u[i];
			sumvv[i] = sumvv[i] + vals[m].v[i] * vals[m].v[i];
		}

		result[i].a = averu[i] * averv[i] - (sumuv[i] / 50);
		result[i].b = averu[i] * averu[i] - (sumuu[i] / 50);
		result[i].c = averv[i] * averv[i] - (sumvv[i] / 50);
		//printf("%lf %lf %lf\n", result[i].a, result[i].b, result[i].c);
	}
}

//输出函数
void Output(void){
	//interaction：可以依据具体计算结果进行调整输出格式，以及调整文件保存位置

	//以“写”方式打开结果文件
	FILE* fp;
	fopen_s(&fp, "D:\\Origdata\\output.dat", "w");
	//可以考虑改变文件的路径来改变文件的输出结果
	
	if (fp == NULL) {
		printf("\n保存文件不正常，请核对文件名！\n");
		fclose(fp);
	}

	else {
		rewind(fp);	//使得指针指向文件开头

		//输出文件开头的内容
		fprintf(fp, "TITLE=DynamicStudio Exported Data\n");
		fprintf(fp, "VARIABLES = \"averageU[-]\" \"averageV[-]\" \"averageUV[-]\" \n");
		fprintf(fp, "ZONE T = \"DynamicStudio Data\" I = 136 J = 76 F = POINT\n");
		
		for (int i = 0; i < 10336; i++) {
			fprintf(fp, "%lf %lf %lf\n", result[i].a, result[i].b, result[i].c); //输出一行，换一行
		}

		fclose(fp);
	}
	return;
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件

